<?php

declare(strict_types=1);

namespace App;

use Crab\Contracts\Container\Container;
use Crab\Contracts\Plugin;

/**
 * Where the application's own services are bound.
 */
final class Setup implements Plugin
{
    public function register(Container $container): void
    {
        $container->singleton(Catalog::class, static fn(): Catalog => new Catalog());
    }
}
